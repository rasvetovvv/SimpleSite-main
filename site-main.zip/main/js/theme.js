$(document).ready(function(){
    $('.fullscreen .preloader').fadeOut(5000);
});